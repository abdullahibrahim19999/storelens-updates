import { scanStore, normalizeBase } from '../lib/scrapers/index.js';
import { PLATFORMS } from '../lib/detectors.js';
import {
  categoriesCSV, productsCSV, summaryJSON, downloadText, stamp,
} from '../lib/exporter.js';
import * as drive from '../lib/drive.js';
import { checkForUpdate, getUpdateInfo } from '../lib/updater.js';
import {
  getPrefs, setPrefs, saveScan, getScans, getScanById, deleteScan,
  getRememberedStores, rememberStore, forgetStore,
} from '../lib/state.js';

const $ = (id) => document.getElementById(id);
const PAGE_SIZE = 50;

let current = null;          // active scan record (live or from history)
let prefs = {};
let toastTimer = null;
let scanBusy = false;

/* ---------------- utils ---------------- */
function toast(msg, err = false) {
  const t = $('toast');
  t.innerHTML = msg;
  t.classList.toggle('toast--err', err);
  t.classList.add('toast--show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('toast--show'), err ? 5200 : 3200);
}

const nf = new Intl.NumberFormat('en-US');
const fmtNum = (n) => (n == null ? '—' : nf.format(n));

function fmtDuration(ms) {
  if (ms < 1000) return `${ms} مللي ثانية`;
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s} ثانية`;
  const minutes = Math.floor(s / 60);
  const seconds = s % 60;
  return `${minutes} دقيقة${seconds ? ` و${seconds} ثانية` : ''}`;
}

function fmtWhen(ts) {
  const d = new Date(ts);
  return d.toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });
}

function fileName(prefix, ext) {
  return `storelens_${current.domain.replace(/^www\./, '')}_${stamp()}_${prefix}.${ext}`;
}

async function captureOpenStore(input) {
  if (!globalThis.chrome?.tabs?.query || !chrome.scripting?.executeScript) return null;
  let wanted;
  try { wanted = new URL(input.includes('://') ? input : `https://${input}`); } catch { return null; }
  const tabs = await chrome.tabs.query({});
  const matchingTabs = tabs.filter((item) => {
    try {
      const openHost = new URL(item.url).hostname.replace(/^www\./i, '');
      const wantedHost = wanted.hostname.replace(/^www\./i, '');
      return /^https?:/.test(item.url || '') && openHost === wantedHost;
    } catch { return false; }
  });
  matchingTabs.sort((a, b) => Number(b.active) - Number(a.active) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
  const tab = matchingTabs[0];
  if (!tab?.id) return null;
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async () => {
        const apiResponses = [];
        let capturedBytes = 0;
        const capture = (url, contentType, body) => {
          if (!/json/i.test(contentType || '') || !body || capturedBytes >= 5_000_000) return;
          const text = String(body).slice(0, 1_000_000);
          capturedBytes += text.length;
          apiResponses.push({ url: String(url), body: text });
        };
        const originalFetch = window.fetch;
        const originalOpen = XMLHttpRequest.prototype.open;
        const originalSend = XMLHttpRequest.prototype.send;
        window.fetch = async (...args) => {
          const response = await originalFetch(...args);
          try {
            const clone = response.clone();
            capture(clone.url, clone.headers.get('content-type'), await clone.text());
          } catch { /* opaque or streaming response */ }
          return response;
        };
        XMLHttpRequest.prototype.open = function patchedOpen(method, url, ...rest) {
          this.__storeLensUrl = url;
          return originalOpen.call(this, method, url, ...rest);
        };
        XMLHttpRequest.prototype.send = function patchedSend(...args) {
          this.addEventListener('load', () => {
            try {
              const body = this.responseType === 'json' ? JSON.stringify(this.response) : this.responseText;
              capture(this.responseURL || this.__storeLensUrl, this.getResponseHeader('content-type'), body);
            } catch { /* binary response */ }
          }, { once: true });
          return originalSend.apply(this, args);
        };

        const initialY = scrollY;
        let stable = 0;
        let lastHeight = document.documentElement.scrollHeight;
        for (let i = 0; i < 15 && stable < 3; i++) {
          scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' });
          await new Promise((resolve) => setTimeout(resolve, 450));
          const height = document.documentElement.scrollHeight;
          stable = height === lastHeight ? stable + 1 : 0;
          lastHeight = height;
        }
        window.fetch = originalFetch;
        XMLHttpRequest.prototype.open = originalOpen;
        XMLHttpRequest.prototype.send = originalSend;
        scrollTo({ top: initialY, behavior: 'instant' });

        const absoluteLinks = [...document.querySelectorAll('a[href]')]
          .map((a) => a.href).filter((href) => /^https?:/i.test(href));
        const resources = performance.getEntriesByType('resource')
          .filter((entry) => ['fetch', 'xmlhttprequest'].includes(entry.initiatorType))
          .map((entry) => entry.name).filter((href) => /^https?:/i.test(href));
        return {
          url: location.href,
          lang: document.documentElement.lang || '',
          title: document.title,
          html: document.documentElement.outerHTML,
          links: [...new Set(absoluteLinks)].slice(0, 50000),
          resources: [...new Set(resources)].slice(-3000),
          apiResponses,
          capturedAt: Date.now(),
        };
      },
    });
    return result?.result || null;
  } catch { return null; }
}

/* ---------------- theme ---------------- */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
}
async function toggleTheme() {
  prefs = await setPrefs({ theme: prefs.theme === 'dark' ? 'light' : 'dark' });
  applyTheme(prefs.theme);
}
$('themeBtn').addEventListener('click', () => toggleTheme().catch((e) => toast(e.message, true)));

/* ---------------- tabs ---------------- */
function switchTab(name) {
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('tab--active', b.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('tab-panel--active', p.id === `tab-${name}`));
}
$('tabsNav').addEventListener('click', (e) => {
  const btn = e.target.closest('.tab');
  if (btn) switchTab(btn.dataset.tab);
});

/* ---------------- progress ---------------- */
function setProgress(on) {
  $('progressWrap').hidden = !on;
  if (on) {
    $('progressFill').style.width = '0%';
    $('progressPct').textContent = '0%';
    $('progressLabel').textContent = '…';
  }
}
function onProgress({ pct, label }) {
  const p = Math.max(0, Math.min(100, Math.round(pct || 0)));
  $('progressFill').style.width = `${p}%`;
  $('progressPct').textContent = `${p}%`;
  if (label) $('progressLabel').textContent = label;
}

/* ---------------- scanning ---------------- */
async function runScan(inputs = [$('urlInput').value.trim()]) {
  if (scanBusy) return;
  let bases;
  try {
    bases = [...new Set(inputs.map((input) => normalizeBase(input)))];
    if (!bases.length) throw new Error('اكتب رابط متجر واحد على الأقل');
  } catch (e) { toast(e.message, true); return; }
  const platform = $('platformSel').value;
  scanBusy = true;
  $('scanBtn').disabled = true;
  $('batchStart').disabled = true;
  $('scanBtnLabel').textContent = 'جارٍ السحب…';
  setProgress(true);
  switchTab('overview');
  let succeeded = 0;
  let failed = 0;
  let partial = 0;
  try {
    for (let i = 0; i < bases.length; i++) {
      const base = bases[i];
      $('batchStatus').textContent = `المتجر ${i + 1} من ${bases.length}: ${base}`;
      try {
        await rememberStore(base, { status: 'running' });
        onProgress({ pct: 0, label: `المتجر ${i + 1}/${bases.length}: قراءة ${base}…` });
        const browserContext = await captureOpenStore(base);
        const scan = await scanStore(base, {
          platform,
          onProgress: ({ pct, label }) => onProgress({
            pct: ((i + (pct || 0) / 100) / bases.length) * 100,
            label: `المتجر ${i + 1}/${bases.length}: ${label || base}`,
          }),
          opts: {
            delayMs: prefs.delayMs ?? 200,
            maxPages: prefs.maxPages ?? 20,
            maxProductsPerRun: prefs.maxProductsPerRun ?? 500,
            maxCategories: prefs.maxCategories ?? 100,
            perCollectionCounts: prefs.perCollectionCounts !== false,
            preferredLanguage: prefs.preferredLanguage || 'ar',
            fullScan: prefs.fullScan !== false,
            browserContext,
          },
        });
        await saveScan(scan);
        const isPartial = Boolean(scan.diagnostics?.partial);
        await rememberStore(base, {
          status: isPartial ? 'partial' : 'success', lastScan: scan.ts,
          totalProducts: scan.totalProducts, error: isPartial ? (scan.notes || []).filter((note) => /جزئي|متبق|فشل|تعذّر|مراجعة/.test(note)).join('؛ ') : '',
        });
        if (isPartial) partial++;
        else succeeded++;
        render(scan);
        try { chrome.runtime.sendMessage({ type: 'scan-done' }).catch?.(() => {}); } catch { /* plain browser */ }
      } catch (e) {
        failed++;
        await rememberStore(base, { status: 'failed', lastScan: Date.now(), error: e.message || 'فشل السحب' });
      }
      await renderHistory();
    }
    $('batchStatus').textContent = `اكتمل السحب: ${succeeded} مكتمل، ${partial} جزئي، ${failed} فشل`;
    toast(bases.length === 1 && succeeded ? `تم سحب <b dir="ltr">${bases[0]}</b>`
      : `اكتمل السحب: ${succeeded} مكتمل، ${partial} جزئي، ${failed} فشل`, failed > 0 || partial > 0);
  } finally {
    scanBusy = false;
    $('scanBtn').disabled = false;
    $('batchStart').disabled = false;
    $('scanBtnLabel').textContent = 'اسحب المتجر';
    setTimeout(() => setProgress(false), 900);
  }
}
$('scanForm').addEventListener('submit', (e) => { e.preventDefault(); runScan(); });
$('batchToggle').addEventListener('click', () => { $('batchPanel').hidden = !$('batchPanel').hidden; });
$('batchClose').addEventListener('click', () => { $('batchPanel').hidden = true; });
$('batchStart').addEventListener('click', () => {
  const inputs = $('batchUrls').value.split(/[\n,;]+/).map((value) => value.trim()).filter(Boolean);
  runScan(inputs);
});

/* ---------------- overview render ---------------- */
function render(scan) {
  current = scan;
  const fromHistory = scan.products === undefined; // records from storage use same shape; guard anyway
  $('emptyState').hidden = true;
  $('overviewData').hidden = false;

  $('ovDomain').textContent = scan.domain;
  $('ovMeta').textContent = `${PLATFORMS[scan.platform] || scan.platform} · ${fmtWhen(scan.ts)}`;

  $('stProducts').textContent = fmtNum(scan.totalProducts);
  const fetched = (scan.products || []).length;
  $('stProductsHint').textContent = scan.totalProducts != null && scan.totalProducts > fetched
    ? `تم جلب ${fmtNum(fetched)} منهم` : `تم جلب ${fmtNum(fetched)}`;

  $('stCategories').textContent = fmtNum(scan.categories.length);
  const known = scan.categories.filter((c) => c.count != null);
  $('stCategoriesHint').textContent = known.length
    ? `${fmtNum(known.reduce((a, c) => a + c.count, 0))} منتج موزّعة على ${known.length} تصنيف مُعدود`
    : 'العدد لكل تصنيف غير متاح في هذا الوضع';

  $('stPlatform').textContent = PLATFORMS[scan.platform] || scan.platform || '—';
  $('stMode').textContent = scan.mode === 'rest' ? 'عبر REST API' : scan.mode === 'json' ? 'عبر JSON API' : scan.mode === 'sitemap' ? 'عبر Sitemap' : scan.mode || '';
  $('stDuration').textContent = scan.durationMs ? fmtDuration(scan.durationMs) : '—';
  $('stWhen').textContent = fmtWhen(scan.ts);

  catState.page = 1;
  renderCategories();

  // types table
  const types = Object.entries(scan.types || {}).sort((a, b) => b[1] - a[1]);
  if (types.length) {
    $('typesPanel').style.display = '';
    $('typesBody').innerHTML = types.slice(0, 50).map(([t, n]) => `<tr><td>${escapeHtml(t)}</td><td class="num"><span class="count-pill">${fmtNum(n)}</span></td></tr>`).join('');
    $('typesNote').textContent = types.length > 50 ? `أول 50 من ${types.length}` : '';
  } else {
    $('typesPanel').style.display = 'none';
    document.querySelector('#tab-overview .grid-2').style.gridTemplateColumns = '1fr';
  }

  const brands = scan.brands || [];
  const brandedProducts = brands.reduce((sum, brand) => sum + (brand.count || 0), 0);
  $('brandsPanel').style.display = brands.length ? '' : 'none';
  $('brandsNote').textContent = brands.length ? `${fmtNum(brands.length)} براند · ${fmtNum(brandedProducts)} منتج معروف البراند` : '';
  $('brandsBody').innerHTML = brands.map((brand) => `<tr>
    <td>${escapeHtml(brand.name)}</td>
    <td class="num"><span class="count-pill">${fmtNum(brand.count)}</span></td>
    <td><div class="share"><div class="share__bar"><div class="share__fill" style="width:${Math.min(100, brand.percentage || 0)}%"></div></div><span class="share__pct">${brand.percentage || 0}%</span></div></td>
  </tr>`).join('');

  // notes
  const diagnostics = scan.diagnostics || {};
  $('diagnosticsCard').hidden = false;
  {
    const quality = diagnostics.quality || {};
    const missingCounts = scan.categories.filter((c) => c.count == null || c.exact === false).length;
    $('diagnosticsText').textContent = [
      diagnostics.partial ? 'النتيجة جزئية؛ راجع الملاحظات والصفحات الفاشلة.' : 'اكتمل السحب من المصدر المتاح.',
      ...(diagnostics.candidateUrlsDiscovered != null ? [`روابط مفحوصة: ${fmtNum(diagnostics.candidateUrlsExamined || 0)} من ${fmtNum(diagnostics.candidateUrlsDiscovered)}.`] : []),
      ...(diagnostics.batches > 1 ? [`دفعات السحب: ${fmtNum(diagnostics.batches)}.`] : []),
      `المنتجات المحفوظة: ${fmtNum(fetched)}.`,
      `بلا سعر: ${fmtNum(quality.missingPrice ?? (scan.products || []).filter((p) => p.price === '' || p.price == null).length)}.`,
      `بلا تصنيف: ${fmtNum(quality.missingType ?? (scan.products || []).filter((p) => !p.type).length)}.`,
      `كمية غير معلنة: ${fmtNum(quality.missingQuantity ?? (scan.products || []).filter((p) => p.quantity == null).length)}.`,
      ...(quality.duplicateProducts ? [`منتجات مكررة دُمجت: ${fmtNum(quality.duplicateProducts)}.`] : []),
      ...['productPagesFailed', 'collectionPagesFailed', 'categoryPagesFailed', 'stockPagesFailed', 'detailPagesFailed'].filter((key) => diagnostics[key]).map((key) => `${({ productPagesFailed: 'صفحات المنتجات', collectionPagesFailed: 'قوائم التصنيفات', categoryPagesFailed: 'صفحات التصنيفات', stockPagesFailed: 'صفحات المخزون', detailPagesFailed: 'صفحات التفاصيل' })[key]} الفاشلة: ${fmtNum(diagnostics[key])}.`),
      ...(diagnostics.failedSitemaps?.length ? [`خرائط فاشلة: ${fmtNum(diagnostics.failedSitemaps.length)}.`] : []),
      `تصنيفات بلا عدد موثوق: ${fmtNum(missingCounts)}.`,
    ].join(' ');
  }
  const notes = scan.notes || [];
  $('notesCard').hidden = !notes.length;
  $('notesList').innerHTML = notes.map((n) => `<li>${escapeHtml(n)}</li>`).join('');

  // products tab
  const badge = $('productsBadge');
  badge.textContent = fmtNum(fetched);
  badge.hidden = false;
  buildCatFilter();
  prodState.page = 1;
  renderProducts();
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

function safeHttpUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return /^https?:$/.test(url.protocol) ? escapeHtml(url.href) : '';
  } catch { return ''; }
}

/* ---------------- categories table ---------------- */
const catState = { page: 1 };

function renderCategories() {
  if (!current) return;
  const all = current.categories || [];
  const pages = Math.max(1, Math.ceil(all.length / PAGE_SIZE));
  catState.page = Math.max(1, Math.min(catState.page, pages));
  const start = (catState.page - 1) * PAGE_SIZE;
  const slice = all.slice(start, start + PAGE_SIZE);
  const maxCount = Math.max(0, ...all.map((c) => c.count || 0));
  const totalKnown = all.reduce((sum, c) => sum + (c.count || 0), 0);

  $('catsBody').innerHTML = slice.map((c) => {
    const share = totalKnown && c.count ? Math.round((c.count / totalKnown) * 100) : 0;
    const width = maxCount ? Math.round(((c.count || 0) / maxCount) * 100) : 0;
    const label = c.exact ? fmtNum(c.count) : c.count != null ? `${nf.format(c.count)}+` : '—';
    const title = c.exact ? '' : c.count != null ? 'عدد تقريبي (تم الوصول لحد الطلبات)' : 'غير معروف في هذا الوضع';
    const name = escapeHtml(c.name || '—');
    const categoryUrl = safeHttpUrl(c.url);
    return `<tr>
      <td>${categoryUrl ? `<a href="${categoryUrl}" target="_blank" rel="noreferrer">${name}</a>` : name}</td>
      <td class="num"><span class="count-pill" title="${title}">${label}</span></td>
      <td><div class="share"><div class="share__bar"><div class="share__fill" style="width:${width}%"></div></div><span class="share__pct">${share}%</span></div></td>
    </tr>`;
  }).join('') || `<tr><td colspan="3" class="muted" style="text-align:center;padding:26px">لا توجد تصنيفات</td></tr>`;

  $('catsPageInfo').textContent = `${catState.page} / ${pages}`;
  $('catsPagePrev').disabled = catState.page <= 1;
  $('catsPageNext').disabled = catState.page >= pages;
  $('catsPager').hidden = all.length <= PAGE_SIZE;
  $('catsTotalNote').textContent = all.length ? `عرض ${fmtNum(start + 1)}–${fmtNum(Math.min(start + PAGE_SIZE, all.length))} من ${fmtNum(all.length)}` : '';
}

$('catsPagePrev').addEventListener('click', () => { catState.page--; renderCategories(); });
$('catsPageNext').addEventListener('click', () => { catState.page++; renderCategories(); });

/* ---------------- products tab ---------------- */
const prodState = { q: '', cat: '', page: 1 };

function buildCatFilter() {
  const sel = $('prodCatFilter');
  const cats = [...new Set((current.products || []).map((p) => p.type).filter(Boolean))].sort();
  sel.innerHTML = '<option value="">كل التصنيفات</option>' + cats.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  sel.value = '';
  prodState.cat = '';
}

function filteredProducts() {
  const q = prodState.q.trim().toLowerCase();
  return (current.products || []).filter((p) => {
    if (prodState.cat && p.type !== prodState.cat) return false;
    if (!q) return true;
    return (
      (p.title || '').toLowerCase().includes(q)
      || (p.type || '').toLowerCase().includes(q)
      || (p.tags || []).some((t) => t.toLowerCase().includes(q))
    );
  });
}

function renderProducts() {
  if (!current) return;
  const all = filteredProducts();
  const pages = Math.max(1, Math.ceil(all.length / PAGE_SIZE));
  prodState.page = Math.min(prodState.page, pages);
  const slice = all.slice((prodState.page - 1) * PAGE_SIZE, prodState.page * PAGE_SIZE);

  $('prodCount').textContent = `${fmtNum(all.length)} منتج`;
  $('prodsBody').innerHTML = slice.map((p) => {
    const imageUrl = safeHttpUrl(p.image);
    const productUrl = safeHttpUrl(p.url);
    const img = imageUrl
      ? `<img class="prod-img" loading="lazy" src="${imageUrl}" alt="">`
      : '<span class="prod-img prod-img--empty">—</span>';
    const tags = (p.tags || []).slice(0, 3).map((t) => `<span class="tag">${escapeHtml(t)}</span>`).join('');
    const quantity = p.quantity != null ? `${fmtNum(p.quantity)}${p.availability === 'out_of_stock' ? ' · غير متوفر' : p.availability === 'preorder' ? ' · طلب مسبق' : ''}`
      : p.availability === 'out_of_stock' ? 'غير متوفر'
        : p.availability === 'preorder' ? 'طلب مسبق · العدد غير معلن'
        : p.availability === 'in_stock' ? 'متوفر · العدد غير معلن' : 'غير معلنة';
    const price = [p.price, p.currency].filter(Boolean).join(' ') || '—';
    return `<tr>
      <td>${img}</td>
      <td>${productUrl ? `<a href="${productUrl}" target="_blank" rel="noreferrer">${escapeHtml(p.title || '—')}</a>` : escapeHtml(p.title || '—')}</td>
      <td>${escapeHtml(p.type || '—')}</td>
      <td class="num">${escapeHtml(price)}</td>
      <td class="num">${escapeHtml(quantity)}</td>
      <td>${tags}</td>
    </tr>`;
  }).join('') || `<tr><td colspan="6" class="muted" style="text-align:center;padding:30px">لا نتائج مطابقة</td></tr>`;

  $('pageInfo').textContent = `${prodState.page} / ${pages}`;
  $('pagePrev').disabled = prodState.page <= 1;
  $('pageNext').disabled = prodState.page >= pages;
}

$('prodSearch').addEventListener('input', (e) => { prodState.q = e.target.value; prodState.page = 1; renderProducts(); });
$('prodCatFilter').addEventListener('change', (e) => { prodState.cat = e.target.value; prodState.page = 1; renderProducts(); });
$('pagePrev').addEventListener('click', () => { prodState.page--; renderProducts(); });
$('pageNext').addEventListener('click', () => { prodState.page++; renderProducts(); });

/* ---------------- history ---------------- */
async function renderHistory() {
  const scans = await getScans();
  const stores = await getRememberedStores();
  $('storesNote').textContent = stores.length ? `${stores.length} متجر محفوظ` : '';
  $('storesBody').innerHTML = stores.map((s) => `<tr>
      <td><span dir="ltr">${escapeHtml(s.domain)}</span></td>
      <td>${s.status === 'success' ? `${fmtNum(s.totalProducts)} منتج` : s.status === 'partial'
        ? `<span title="${escapeHtml(s.error || '')}">جزئي · ${fmtNum(s.totalProducts)} منتج</span>` : s.status === 'failed'
        ? `<span class="muted" title="${escapeHtml(s.error || '')}">فشل السحب</span>`
        : scanBusy ? 'جارٍ السحب' : 'لم يكتمل'}</td>
      <td class="muted">${s.lastScan ? fmtWhen(s.lastScan) : '—'}</td>
      <td><div class="row-actions">
        <button class="link-btn" data-rescan="${escapeHtml(s.base)}">إعادة السحب</button>
        <button class="link-btn link-btn--danger" data-forget="${escapeHtml(s.base)}">حذف</button>
      </div></td>
    </tr>`).join('') || `<tr><td colspan="4" class="muted" style="text-align:center;padding:30px">لم تسحب أي متجر بعد</td></tr>`;
  $('historyNote').textContent = scans.length ? `آخر ${scans.length} عملية` : '';
  $('historyBody').innerHTML = scans.map((s) => `<tr>
      <td><span dir="ltr">${escapeHtml(s.domain)}</span></td>
      <td>${PLATFORMS[s.platform] || s.platform}</td>
      <td class="num">${fmtNum(s.totalProducts ?? s.fetchedProducts)}</td>
      <td class="num">${fmtNum(s.categoriesCount)}</td>
      <td class="muted">${fmtWhen(s.ts)}</td>
      <td><div class="row-actions">
        <button class="link-btn" data-view="${s.id}">عرض</button>
        <button class="link-btn link-btn--danger" data-del="${s.id}">حذف</button>
      </div></td>
    </tr>`).join('') || `<tr><td colspan="6" class="muted" style="text-align:center;padding:30px">لا يوجد سجل بعد</td></tr>`;
}

$('storesBody').addEventListener('click', async (e) => {
  const rescan = e.target.closest('[data-rescan]');
  const forget = e.target.closest('[data-forget]');
  if (rescan) {
    if (scanBusy) return;
    $('urlInput').value = rescan.dataset.rescan;
    runScan([rescan.dataset.rescan]);
  } else if (forget) {
    if (scanBusy) return;
    await forgetStore(forget.dataset.forget);
    await renderHistory();
  }
});

$('historyBody').addEventListener('click', async (e) => {
  const view = e.target.closest('[data-view]');
  const del = e.target.closest('[data-del]');
  if (view) {
    const rec = await getScanById(view.dataset.view);
    if (rec) {
      $('urlInput').value = rec.base || rec.domain;
      render(rec);
      switchTab('overview');
    }
  } else if (del) {
    await deleteScan(del.dataset.del);
    renderHistory();
    toast('تم الحذف من السجل');
  }
});

/* ---------------- exports ---------------- */
$('expCats').addEventListener('click', () => {
  if (!current) return;
  downloadText(fileName('categories', 'csv'), categoriesCSV(current), 'text/csv');
});
$('expProds').addEventListener('click', () => {
  if (!current) return;
  downloadText(fileName('products', 'csv'), productsCSV(current), 'text/csv');
});
$('expJson').addEventListener('click', () => {
  if (!current) return;
  downloadText(fileName('summary', 'json'), summaryJSON(current), 'application/json');
});

/* ---------------- drive ---------------- */
function refreshDriveChip() {
  const on = drive.isConfigured();
  $('driveChip').classList.toggle('drive-chip--on', on);
  $('driveChipText').textContent = on ? 'Drive جاهز' : 'Drive غير مُعد';
  $('driveStatusLine').textContent = on
    ? 'الإكستنشن مُعدّة للمزامنة — سيتم الرفع لمجلد StoreLens في حسابك على Google Drive عند الضغط على «مزامنة على Drive».'
    : 'لم يتم ضبط OAuth بعد. اتبع الخطوات جانبًا لتفعيل المزامنة، أو استخدم أداة بايثون المرفقة (ترفع على Drive بصلاحيات أسهل).';
}
refreshDriveChip();

$('driveBtn').addEventListener('click', async () => {
  if (!current) return;
  if (!drive.isConfigured()) {
    toast('اضبط Google OAuth أولًا — الخطوات في تبويب الإعدادات', true);
    switchTab('settings');
    return;
  }
  const btn = $('driveBtn');
  btn.disabled = true;
  try {
    const res = await drive.syncScan(current, [
      { name: fileName('categories', 'csv'), content: categoriesCSV(current), mime: 'text/csv' },
      { name: fileName('products', 'csv'), content: productsCSV(current), mime: 'text/csv' },
      { name: fileName('summary', 'json'), content: summaryJSON(current), mime: 'application/json' },
    ]);
    const links = res.uploaded.map((f) => `<a href="${f.link}" target="_blank" rel="noreferrer">${f.name}</a>`).join(' · ');
    toast(`تم الرفع على Drive في مجلد <b dir="ltr">StoreLens/${current.domain}</b>: ${links}`);
  } catch (e) {
    toast(e.message || 'فشل الرفع على Drive', true);
  } finally {
    btn.disabled = false;
  }
});

$('driveSignOut').addEventListener('click', async () => {
  try {
    await drive.signOut();
    toast('تم فصل حساب Google محليًا');
  } catch {
    toast('غير متاح خارج الإكستنشن', true);
  }
});

/* ---------------- settings ---------------- */
function loadSettingsUI() {
  $('setDelay').value = prefs.delayMs ?? 200;
  $('setMaxPages').value = prefs.maxPages ?? 20;
  $('setMaxProductsPerRun').value = prefs.maxProductsPerRun ?? 500;
  $('setMaxCats').value = prefs.maxCategories ?? 100;
  $('setPerCat').checked = prefs.perCollectionCounts !== false;
  $('setRepo').value = prefs.githubRepo || '';
  $('setAutoCheck').checked = prefs.autoUpdateCheck !== false;
}
$('saveSettings').addEventListener('click', async () => {
  prefs = await setPrefs({
    delayMs: Math.min(3000, Math.max(50, parseInt($('setDelay').value, 10) || 200)),
    maxPages: Math.min(100, Math.max(1, parseInt($('setMaxPages').value, 10) || 20)),
    maxProductsPerRun: Math.min(2000, Math.max(20, parseInt($('setMaxProductsPerRun').value, 10) || 500)),
    maxCategories: Math.min(500, Math.max(5, parseInt($('setMaxCats').value, 10) || 100)),
    perCollectionCounts: $('setPerCat').checked,
    githubRepo: $('setRepo').value.trim(),
    autoUpdateCheck: $('setAutoCheck').checked,
  });
  loadSettingsUI();
  toast('تم حفظ الإعدادات');
});

/* ---------------- GitHub updates ---------------- */
function showUpdateBanner(info) {
  if (!info || info.status !== 'update') return;
  $('updateVer').textContent = `v${info.latest}`;
  $('updateNotes').textContent = info.notes || '';
  $('updateDownload').href = info.url;
  $('updateBar').hidden = false;
}
$('updateDismiss').addEventListener('click', () => { $('updateBar').hidden = true; });

$('checkUpdateBtn').addEventListener('click', async () => {
  const btn = $('checkUpdateBtn');
  prefs = await setPrefs({ githubRepo: $('setRepo').value.trim(), autoUpdateCheck: $('setAutoCheck').checked });
  btn.disabled = true;
  btn.textContent = 'جارٍ الفحص…';
  try {
    const res = await checkForUpdate();
    if (res.status === 'no-repo') {
      $('updateStatusLine').textContent = 'اكتب المستودع أولًا بصيغة owner/repo.';
    } else if (res.status === 'error') {
      $('updateStatusLine').textContent = `فشل الفحص: ${res.message}`;
    } else if (res.status === 'update') {
      $('updateStatusLine').textContent = `يوجد إصدار أحدث v${res.latest} (الحالي v${res.current}).`;
      $('updateCardLink').href = res.url;
      $('updateCardLink').hidden = false;
      showUpdateBanner(res);
    } else {
      $('updateStatusLine').textContent = `أنت على أحدث إصدار (v${res.current}).`;
    }
  } finally {
    btn.disabled = false;
    btn.textContent = 'تحقق من تحديث الآن';
  }
});

/* ---------------- init ---------------- */
(async function init() {
  prefs = await getPrefs();
  applyTheme(prefs.theme || 'dark');
  loadSettingsUI();
  renderHistory();
  getUpdateInfo().then(showUpdateBanner).catch(() => {});

  const params = new URLSearchParams(location.search);
  const url = params.get('url');
  if (url) $('urlInput').value = url;
  if (params.get('autostart') === '1' && url) runScan();
})().catch((e) => toast(e.message || 'خطأ في التحميل', true));

// Debug/demo hook: lets the page be previewed with sample data outside the extension.
window.storelens = { render, runScan, scanStore };
