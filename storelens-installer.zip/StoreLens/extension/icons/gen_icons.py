"""Generate StoreLens icons (16/32/48/128) — dark rounded tile + white-to-gray
gradient magnifier. Run: python icons/gen_icons.py"""

import os

from PIL import Image, ImageDraw, ImageFont

SIZES = [16, 32, 48, 128]
HERE = os.path.dirname(os.path.abspath(__file__))

TOP = (16, 17, 22)
BOTTOM = (38, 41, 50)
WHITE = (245, 246, 248)
GRAY = (140, 146, 158)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient_tile(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    tile = Image.new("RGBA", (size, size))
    px = tile.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * size - 2)
            px[x, y] = (*lerp(TOP, BOTTOM, t), 255)
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=max(3, size // 5), fill=255)
    img.paste(tile, (0, 0), mask)
    return img


def draw_lens(img, size):
    d = ImageDraw.Draw(img)
    cx, cy = size * 0.44, size * 0.44
    r = size * 0.26
    lw = max(2, int(size * 0.075))

    # gradient ring: draw two arcs (top-left white → bottom-right gray)
    d.arc([cx - r, cy - r, cx + r, cy + r], 100, 300, fill=WHITE, width=lw)
    d.arc([cx - r, cy - r, cx + r, cy + r], 280, 100, fill=GRAY, width=lw)

    # handle
    hx1, hy1 = cx + r * 0.72, cy + r * 0.72
    hx2, hy2 = cx + r * 1.45, cy + r * 1.45
    d.line([hx1, hy1, hx2, hy2], fill=WHITE, width=lw + max(1, size // 32))

    # scan bars inside the lens
    bar_w = r * 1.05
    for i, dy in enumerate((-0.38, 0.0, 0.38)):
        y = cy + r * dy
        color = WHITE if i == 1 else GRAY
        d.line([cx - bar_w / 2 + r * 0.1, y, cx + bar_w / 2 - r * 0.1, y],
               fill=color, width=max(1, int(lw * 0.66)))


def main():
    for s in SIZES:
        img = gradient_tile(s)
        draw_lens(img, s)
        img.save(os.path.join(HERE, f"icon{s}.png"))
        print(f"icon{s}.png ✓")


if __name__ == "__main__":
    main()
