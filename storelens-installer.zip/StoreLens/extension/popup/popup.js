import { probePlatform, PLATFORMS } from '../lib/detectors.js';
import { getScans, getPrefs } from '../lib/state.js';
import { getUpdateInfo } from '../lib/updater.js';

const $ = (id) => document.getElementById(id);

let currentOrigin = null;
let toastTimer = null;

function toast(msg, err = false) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('toast--err', err);
  t.classList.add('toast--show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('toast--show'), 2600);
}

function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'الآن';
  if (s < 3600) return `منذ ${Math.floor(s / 60)} دقيقة`;
  if (s < 86400) return `منذ ${Math.floor(s / 3600)} ساعة`;
  return `منذ ${Math.floor(s / 86400)} يوم`;
}

function setPlatform(name, loading = false) {
  const chip = $('platformChip');
  $('platformName').textContent = name;
  chip.classList.toggle('chip--loading', loading);
}

async function init() {
  const prefs = await getPrefs();
  document.documentElement.dataset.theme = prefs.theme || 'dark';

  const hasTabs = globalThis.chrome && chrome.tabs && chrome.tabs.query;
  if (!hasTabs) {
    $('domain').textContent = '—';
    setPlatform('يعمل داخل الإكستنشن فقط');
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab && tab.url && /^https?:/i.test(tab.url) ? new URL(tab.url) : null;

  if (!url) {
    $('domain').textContent = '—';
    setPlatform('افتح صفحة متجر أولًا');
    return;
  }

  currentOrigin = url.origin;
  $('domain').textContent = url.hostname;
  $('scanBtn').disabled = false;

  // Fire-and-forget detection with a short timeout.
  probePlatform(currentOrigin, { timeout: 9000, delayMs: 0 })
    .then((p) => setPlatform(PLATFORMS[p] || p || 'غير معروف'))
    .catch(() => setPlatform('غير معروف'));

  // Latest scan stats for this domain + recent list.
  const scans = await getScans();
  const last = scans.find((s) => s.domain === url.hostname);
  if (last) {
    $('statProducts').textContent = last.totalProducts != null ? last.totalProducts : last.fetchedProducts;
    $('statCategories').textContent = last.categoriesCount;
    $('lastStats').hidden = false;
  }
  const recent = scans.slice(0, 5);
  if (recent.length) {
    $('recentWrap').hidden = false;
    const list = $('recentList');
    recent.forEach((s) => {
      const li = document.createElement('li');
      li.className = 'recent__item';
      li.innerHTML = `<span class="recent__dom">${s.domain}</span>
        <span class="recent__meta">${s.totalProducts ?? s.fetchedProducts} منتج · ${timeAgo(s.ts)}</span>`;
      li.addEventListener('click', () => openDashboard(s.base, false));
      list.appendChild(li);
    });
  }

  // GitHub update banner (if a newer release was detected by the worker).
  try {
    const info = await getUpdateInfo();
    if (info && info.status === 'update') {
      $('popUpdateVer').textContent = `v${info.latest}`;
      $('popUpdate').href = info.url;
      $('popUpdate').hidden = false;
    }
  } catch { /* ignore */ }
}

function openDashboard(url, autoscan) {
  const q = new URLSearchParams();
  if (url) q.set('url', url);
  if (autoscan) q.set('autostart', '1');
  chrome.tabs.create({ url: chrome.runtime.getURL(`dashboard/dashboard.html?${q.toString()}`) });
  window.close();
}

$('scanBtn').addEventListener('click', () => {
  if (currentOrigin) openDashboard(currentOrigin, true);
  else toast('افتح صفحة المتجر في التاب الحالي أولًا', true);
});
$('dashBtn').addEventListener('click', () => openDashboard(null, false));

init().catch((e) => {
  setPlatform('خطأ');
  toast(e.message || 'حدث خطأ غير متوقع', true);
});
