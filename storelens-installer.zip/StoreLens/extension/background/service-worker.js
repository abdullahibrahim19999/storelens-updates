// StoreLens service worker: scan badge + update checks.

import {
  ALARM_NAME,
  LOCAL_RELOAD_ALARM,
  checkForUpdate,
  checkLocalPackageRefresh,
  scheduleDailyCheck,
  scheduleLocalReloadCheck,
} from '../lib/updater.js';

function scheduleUpdateChecks() {
  scheduleDailyCheck();
  scheduleLocalReloadCheck();
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
  scheduleUpdateChecks();
  checkLocalPackageRefresh().catch(() => {});
  checkForUpdate().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  scheduleUpdateChecks();
  checkLocalPackageRefresh().catch(() => {});
  checkForUpdate().catch(() => {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    checkForUpdate().catch(() => {});
  } else if (alarm.name === LOCAL_RELOAD_ALARM) {
    checkLocalPackageRefresh().catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'scan-done') {
    chrome.action.setBadgeBackgroundColor({ color: '#e8eaef' });
    chrome.action.setBadgeTextColor({ color: '#0b0c0f' });
    chrome.action.setBadgeText({ text: '✓' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 6000);
  }
});
