param()

$ErrorActionPreference = "Stop"

$bundleRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$sourceExtension = Join-Path $bundleRoot "extension"
if (-not (Test-Path (Join-Path $sourceExtension "manifest.json"))) {
  Write-Host "StoreLens extension folder was not found next to the installer." -ForegroundColor Red
  exit 1
}

$installRoot = Join-Path $env:LOCALAPPDATA "StoreLens"
$extensionPath = Join-Path $installRoot "extension"
$updaterPath = Join-Path $installRoot "updater"
New-Item -ItemType Directory -Force -Path $extensionPath, $updaterPath | Out-Null

foreach ($dir in @("background", "dashboard", "icons", "lib", "popup")) {
  $src = Join-Path $sourceExtension $dir
  $dst = Join-Path $extensionPath $dir
  if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
  Copy-Item -Recurse -Force $src $dst
}
Copy-Item -Force (Join-Path $sourceExtension "manifest.json") (Join-Path $extensionPath "manifest.json")
Copy-Item -Force (Join-Path $sourceExtension "version.json") (Join-Path $extensionPath "version.json")

$sourceUpdater = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "StoreLens-Updater.ps1"
$targetUpdater = Join-Path $updaterPath "StoreLens-Updater.ps1"
Copy-Item -Force $sourceUpdater $targetUpdater

$config = @{
  extensionPath = $extensionPath
  manifestUrl = "https://raw.githubusercontent.com/abdullahibrahim19999/storelens-updates/main/version.json"
} | ConvertTo-Json
Set-Content -Path (Join-Path $updaterPath "config.json") -Value $config -Encoding UTF8

$psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$action = New-ScheduledTaskAction -Execute $psExe -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$targetUpdater`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 15) -RepetitionDuration (New-TimeSpan -Days 3650)
Register-ScheduledTask -TaskName "StoreLens Auto Update" -Action $action -Trigger $trigger -Description "Keeps the unpacked StoreLens Chrome extension updated from GitHub." -Force | Out-Null

& $psExe -NoProfile -ExecutionPolicy Bypass -File $targetUpdater

Write-Host ""
Write-Host "StoreLens is installed here:" -ForegroundColor Green
Write-Host $extensionPath -ForegroundColor Cyan
Write-Host ""
Write-Host "Auto-update checks every 15 minutes." -ForegroundColor Green
Write-Host "Chrome will reload the extension automatically after files are updated." -ForegroundColor Green
Write-Host ""
Write-Host "Next: open chrome://extensions, enable Developer mode, choose Load unpacked, and select the folder above." -ForegroundColor Yellow

Start-Process explorer.exe $extensionPath
try { Start-Process "chrome.exe" "chrome://extensions" } catch { }

Write-Host ""
Read-Host "Press Enter to close"
